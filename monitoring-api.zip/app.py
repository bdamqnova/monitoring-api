from flask import Flask, request, jsonify
import logging
import os
import psycopg2

app = Flask(__name__)
app.config["JSON_SORT_KEYS"] = False

os.makedirs("logs", exist_ok=True)

logging.basicConfig(
    filename="logs/app.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

DB_HOST = os.getenv("DB_HOST", "pg-monitoring-es.postgres.database.azure.com")
DB_NAME = os.getenv("DB_NAME", "postgres")
DB_USER = os.getenv("DB_USER", "pgadminbisera")
DB_PASSWORD = os.getenv("DB_PASSWORD", "")
DB_PORT = os.getenv("DB_PORT", "5432")


def get_connection():
    return psycopg2.connect(
        host=DB_HOST,
        dbname=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD,
        port=DB_PORT,
        sslmode="require"
    )


def create_table():
    conn = get_connection()
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS monitoring_metrics (
            id SERIAL PRIMARY KEY,
            device_name VARCHAR(100) NOT NULL,
            cpu_percent FLOAT NOT NULL,
            memory_percent FLOAT NOT NULL,
            disk_percent FLOAT NOT NULL,
            timestamp TIMESTAMP NOT NULL
        );
    """)

    conn.commit()
    cur.close()
    conn.close()


@app.route("/")
def home():
    return jsonify({"message": "Monitoring API is running"}), 200


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "healthy"}), 200


@app.route("/api/metrics", methods=["POST"])
def receive_metrics():
    try:
        data = request.get_json()

        if not data:
            logging.warning("Empty or invalid JSON received")
            return jsonify({"error": "Invalid JSON"}), 400

        required_fields = [
            "device_name",
            "cpu_percent",
            "memory_percent",
            "disk_percent",
            "timestamp"
        ]

        for field in required_fields:
            if field not in data:
                logging.warning(f"Missing field: {field}")
                return jsonify({"error": f"Missing field: {field}"}), 400

        conn = get_connection()
        cur = conn.cursor()

        cur.execute("""
            INSERT INTO monitoring_metrics
            (device_name, cpu_percent, memory_percent, disk_percent, timestamp)
            VALUES (%s, %s, %s, %s, %s)
        """, (
            data["device_name"],
            data["cpu_percent"],
            data["memory_percent"],
            data["disk_percent"],
            data["timestamp"]
        ))

        conn.commit()
        cur.close()
        conn.close()

        logging.info(f"Metrics stored successfully in PostgreSQL from {data['device_name']}")

        return jsonify({
            "message": "Metrics received and stored successfully",
            "data": data
        }), 201

    except Exception as e:
        logging.error(f"Server error: {str(e)}")
        return jsonify({"error": str(e)}), 500


@app.route("/api/metrics", methods=["GET"])
def get_metrics():
    try:
        conn = get_connection()
        cur = conn.cursor()

        cur.execute("""
            SELECT id, device_name, cpu_percent, memory_percent, disk_percent, timestamp
            FROM monitoring_metrics
            ORDER BY id DESC
        """)

        rows = cur.fetchall()

        cur.close()
        conn.close()

        result = []
        for row in rows:
            result.append({
                "id": row[0],
                "device_name": row[1],
                "cpu_percent": row[2],
                "memory_percent": row[3],
                "disk_percent": row[4],
                "timestamp": str(row[5])
            })

        return jsonify(result), 200

    except Exception as e:
        logging.error(f"Error reading metrics: {str(e)}")
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    create_table()
    app.run(host="0.0.0.0", port=8000, debug=True)